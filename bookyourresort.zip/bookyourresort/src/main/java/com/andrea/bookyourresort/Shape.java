package com.andrea.bookyourresort;

import java.awt.Graphics;

/**
 * Shape interface. This interface is used to generalize a shape.
 *
 */
public interface Shape {

	/**
	 *  This method draw a shape based on its implementation using x,y coordinates.
	 * 
	 * @param g a Graphics object of the Graphics class.
	 * @param x x coordinate of pool shape.
	 * @param y y coordinate of pool shape.
	 * @param width width of pool shape.
	 * @param height height of pool shape.
	 */
	public void draw(Graphics g, int x, int y, int width, int height);
}
