package com.andrea.bookyourresort;
import java.util.*;

/**
 * Strategy interface used for the payment strategy portion of the system.
 */
public interface PaymentStrategy {

    /**
     * Declaration of the pay method.
     * 
     */
    public void pay();

}