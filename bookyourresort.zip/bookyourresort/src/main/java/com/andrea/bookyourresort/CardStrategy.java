package com.andrea.bookyourresort;
import java.util.*;

import javax.swing.JOptionPane;

/**
 * Class used for the payment of a customer with a payment card.
 */
public class CardStrategy implements PaymentStrategy {
	
    /**
     * Constructor of the CardStrategy class.
     * 
     * @param nameOnCard name of the card holder
     * @param number number of the card
     * @param cvv three-digit code on the back of the card
     * @param expirationDate card expiry date
     */
    public CardStrategy(String nameOnCard, String number, String cvv, String expirationDate) {
    	
    	 this.nameOnCard = nameOnCard;
         this.number = number;
         this.cvv = cvv;
         this.expirationDate = expirationDate;
    }

    /**
     * Declared the string variable nameOnCard.
     */
    private String nameOnCard;

    /**
     * Declared the string variable number.
     */
    private String number;

    /**
     * Declared the string variable cvv.
     */
    private String cvv;

    /**
     * Declared the string variable expirationDate.
     */
    private String expirationDate;

   

    /**
     * Declared executeTransation method. This method will have to be implemented in the future studies.
     * @param amount the amount of the payment.
     */
    protected void executeTransation(String amount) {
    	// TO-DO implement here
    }

    /**
     * This method verify if a payment card is valid.
     * @param text the number of payment card.
     * @return a boolean value.
     */
    public static boolean isValidCC(String text) {
        // How many digits should there be - perhaps it can vary? Anyway should be all digits
        if (!text.matches("\\d+")) {
            throw new RuntimeException(String.format(
                    "CC number %s should be all digits", text));
        }

        // Keep running total
        int sum = 0;

        // 'odd' in the sense of an undefined index, starting at 0
        // so the first odd character will be the second one we look at (index 1)
        boolean odd = false;

        // Start inspecting each digit from right to left
        for (int i = text.length(); --i >= 0;) {
            int n = text.charAt(i) - '0';

            if (odd) {
                // Double each alternate digit
                n *= 2;

                // If result of doubling in two figures, make it one figure
                // which is the sum of the two digits
                if (n > 9) {
                    n -= 9;
                }
            }

            // Accumulate
            sum += n;
            odd = !odd;
        }

        //Accumulated total should be multiple of 10
        return ((sum % 10) == 0);
    }

    /**
     * This method print the successful message if the payment is successful
     */
    @Override
    public void pay() {
    	JOptionPane.showMessageDialog(null, "Payment with CreditCard Successful!");
    }

}