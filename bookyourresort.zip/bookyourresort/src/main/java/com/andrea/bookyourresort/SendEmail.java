package com.andrea.bookyourresort;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import java.util.Properties;

/**
 *	This class is used to send emails to users
 */
public class SendEmail {

	/**
	 * This method sends emails to followers of a certain type of villa
	 * 
	 * @param emails list of emails to send mails to
	 * @param subject subject of the mail
	 * @param body body of the mail
	 * @return boolean true if email was sent, false otherwise
	 */
	public static boolean SendEmailToFollowers(String emails, String subject, String body) {
		final String username = "bookyourresort@libero.it";
        final String password = "bookyourresort5";

        Properties prop = new Properties();
		prop.put("mail.smtp.host", "smtp.libero.it");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        //prop.put("mail.smtp.starttls.enable", "true"); //TLS
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("bookyourresort@libero.it"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(emails)
            );
            message.setSubject(subject);
            message.setText(body);
            
            Transport.send(message);
           
            return true;

        } catch (MessagingException e) {
            e.printStackTrace();
            return false;
        }
	}
	
	/**
	 * @param email email to send mail to
	 * @param customerName name of the customer used for the invoice filename
	 * @param subject subject of the mail
	 * @param body body of the mail
	 * @return boolean true if email was sent, false otherwise
	 */
	public static boolean SendInvoiceToCustomer(String email, String customerName, String subject, String body) {
		final String username = "bookyourresort@libero.it";
        final String password = "bookyourresort5";        
        
        Properties prop = new Properties();
		prop.put("mail.smtp.host", "smtp.libero.it");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        //prop.put("mail.smtp.starttls.enable", "true"); //TLS
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("bookyourresort@libero.it"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(email)
            );
            message.setSubject(subject);

            // create and fill the body part of the message
    	    MimeBodyPart messagePart = new MimeBodyPart();
    	    messagePart.setText(body);
            
    	    // create and fill the attach part
            MimeBodyPart messageAttachPart = new MimeBodyPart();

            Multipart multipart = new MimeMultipart();

            messageAttachPart = new MimeBodyPart();
            
            String pdfFilename = "fattura-"+customerName+".pdf";
            GenerateInvoice generateInvoice = new GenerateInvoice();
            generateInvoice.createPDF(pdfFilename);
            
            String file = "invoices/fattura-"+customerName+".pdf";
            String fileName = "fattura-"+customerName+".pdf";
            DataSource source = new FileDataSource(file);
            messageAttachPart.setDataHandler(new DataHandler(source));
            messageAttachPart.setFileName(fileName);
            
            multipart.addBodyPart(messagePart);
            multipart.addBodyPart(messageAttachPart);
            
            message.setContent(multipart);
            
            Transport.send(message);

            return true;

        } catch (MessagingException e) {
            e.printStackTrace();
            return false;
        }
	}

}