package com.andrea.bookyourresort;
import java.util.*;

/**
 * Piscina Decorator concrete class. 
 */
public class ConcretePiscinaDecorator extends PiscinaDecorator {

    /**
     * Piscina Decorator concrete class constructor
     * 
     * @param VType Villa type chosen by the customer
     */
    public ConcretePiscinaDecorator(Villa VType) {
    	super(VType);
    }
    
    public void addCustomer(String userEmail, String VillaType) {
    	super.addCustomer(userEmail, VillaType+" with pool");
    }

}