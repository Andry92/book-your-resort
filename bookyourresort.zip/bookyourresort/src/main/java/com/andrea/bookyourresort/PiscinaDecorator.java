package com.andrea.bookyourresort;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * PiscinaDecorator class. Abstract class used to add a new functionality (the swimming pool) to ConcreteVilla class object.
 */
public abstract class PiscinaDecorator implements Villa {

    /**
     * Constructor of the PiscinaDecorator class.
     * 
     * @param VType Villa's type object.
     */
    public PiscinaDecorator(Villa VType) {
    	this.VType = VType;
    }

    /**
     * Declared the Villa variable VType.
     */
    private Villa VType;
    
    /**
     * Declared the ArrayList variable piscinaActivity that contains all the possible villas pool activities. 
     */
    static ArrayList<String> piscinaActivity = new ArrayList<String>( Arrays.asList("AcquaGym", "Hydrobike", "Aqua Tabata", "Woga", "Swimming Pool Games") );

    /**
     * This method add a customer as a follower.
     * 
     * @param userEmail customer's email.
     * @param VillaType villa's type chosen by the customer.
     */
    @Override
    public void addCustomer(String userEmail, String VillaType) {
    	VType.addCustomer(userEmail, VillaType);
    }

    /**
     * This method sends email to all followers of the villa type.
     */
    public void sendMessage() {
    	
    	try {
			String subject;
	    	String body;
	    	SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy", Locale.ENGLISH);
	    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
	    	
			String emails = CsvUtilities.getEmailsVillaType(Customer.villaType);
			
			if(!emails.equals("")) {
				int cont = CsvUtilities.checkIfResortIsBusy(Customer.checkIn.toString(), Customer.checkOut.toString(), Customer.villaType);
				Date parsedCheckInDate = sdf.parse(Customer.checkIn.toString());
		    	String checkIn = format.format(parsedCheckInDate);
		    	
		    	Date parsedCheckOutDate = sdf.parse(Customer.checkOut.toString());
		    	String checkOut = format.format(parsedCheckOutDate);
				
				if(cont >= 8) {
					subject = "Booking of Villa with Pool";
					body = "Dear user,"
							+ "\n\nwe wanted to inform you that a user has just booked last Villa with pool available from "+checkIn+" to "+checkOut+"."
							+ "\n\n Best regards,\nBook Your Resort Staff";
				}
				else {
					cont = 8-cont;
					subject = "Booking of Villa with Pool";
					body = "Dear user,"
							+ "\n\nwe wanted to inform you that a user has just booked a Villa with pool from "+checkIn+" to "+checkOut+"."
							+ "\nNumber of Villas available for that date's range: "+cont+""
							+ "\n\nMake your reservation as long as the Villas are available!!"
							+ "\n\nBest regards,\nBook Your Resort Staff";
				}
			
				SendEmail.SendEmailToFollowers(emails, subject, body);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
    }

}