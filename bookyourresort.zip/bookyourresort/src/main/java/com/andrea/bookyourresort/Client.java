package com.andrea.bookyourresort;

import java.util.*;
import com.andrea.bookyourresort.ShapeFactory.ShapeType;

/**
 * Client class. This class represents the start point of Flyweight design pattern.
 * We initialize the shapes that we draw on choose villa panel's grid.
 */
public class Client {
	
	static final ShapeType shapes[] = { ShapeType.RECT_BLUE, ShapeType.RECT_RED, ShapeType.RECTP_BLUE, ShapeType.RECTP_RED, ShapeType.OVAL_RED, ShapeType.OVAL_BLUE };
	static List<Integer> xyVilla = new ArrayList<Integer>();
	
    /**
     * Constructor of the client class.
     * In the body of the constructor we add eight shapes to the x,y coordinates list
     */
    public Client() {
    	int sum = 11;
		for(int i=0; i<8; i++) {
			xyVilla.add(sum);
			sum += 100;
		}    	
    }


    /**
     * This method get the x coordinate of the i-th shape.
     * 
     * @param i i-th shape to draw
     * @return int x coordinate of the i-th shape
     */
    public int getX(int i) {
		return xyVilla.get(i);
	}    
    
    /**
     * Main method used to start the program.
     * 
     * @param args input arguments for main
     */
    public static void main(String[] args) {
    	new AppFrame();
    }

}