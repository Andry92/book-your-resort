package com.andrea.bookyourresort;
import java.util.*;

/**
 * Customer class.
 */
public class Customer {

	/**
     * Constructor of Customer class.
     * 
     * @param name customer's name.
     * @param mobile customer's mobile.
     * @param email customer's email.
     * @param address customer's address.
     * @param activities activities chosen by the customer.
     * @param checkIn check-in chosen by the customer.
     * @param checkOut check-out chosen by the customer.
     * @param villaType villa's type chosen by the customer.
     */
    public Customer(String name, String mobile, String email, String address, ArrayList<String> activities, Date checkIn, Date checkOut, String villaType) {
    	
    	Customer.name=name;
    	Customer.mobile=mobile;
    	Customer.email=email;
    	Customer.address=address;
    	Customer.activities=activities;
    	Customer.checkIn=checkIn;
    	Customer.checkOut=checkOut;
    	Customer.villaType=villaType;
    
    }
   
    /**
     * Declared the string variable villaType.
     */
   public static String villaType;
    
    /**
    * Declared the string variable name.
    */
   public static String name;
    
    /**
    * Declared the string variable mobile.
    */
   public static String mobile;

    /**
     * Declared the string variable email.
     */
    public static String email;
    
    /**
     * Declared the string variable address.
     */
    public static String address;

    /**
     * Declared the ArrayList of a string variables activity.
     */
    public static ArrayList<String> activities= new ArrayList<String>();

    /**
     * Declared the string variable checkIn.
     */
    public static Date checkIn;

    /**
     * Declared the string variable checkOut.
     */
    public static Date checkOut;

    /**
     * This method set the activities chosen by a customer.
     * @param activity activities chosen by a customer.
     */
    public static void setActivities(String activity) {
         getActivities().add(activity);
    }

    /**
     * This method get the activities chosen by a customer.
     * @return activities the ArrayList activities chosen by a customer.
     */
    public static ArrayList<String> getActivities() {
		return activities;
	}
    
    /**
     * Method to get customer's email.
     * @return String Customer's email.
     */
    public String getEmail() {
        return email.toString();
    }

	
   
}