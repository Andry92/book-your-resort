package com.andrea.bookyourresort;

import javax.swing.*;

import com.toedter.calendar.JDateChooser;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * CheckInCheckOut Class.
 */
public class CheckInCheckOutPanel extends JPanel {

	JPanel checkInCheckOut;
	
	/* Attributes to check date */
	LocalDateTime from;
	LocalDateTime to;
	
	static JDateChooser dateChooser_1;
	static JDateChooser dateChooser;
	
	/**
     * Constructor of CheckInCheckOut class that create a new JPanel.
    */
	public CheckInCheckOutPanel() {
		checkInCheckOut = new JPanel();
		checkInCheckOut.setBackground(new Color(240, 255, 255));
		setBounds(0, 83, 900, 600);
		checkInCheckOut.setPreferredSize(new Dimension(900, 600));
		checkInCheckOut.setLayout(null); 
		
		JLabel lblCheckout = new JLabel("Check-out");
		lblCheckout.setForeground(Color.WHITE);
		lblCheckout.setFont(new Font("SansSerif", Font.ITALIC, 31));
		lblCheckout.setBounds(547, 162, 159, 37);
		checkInCheckOut.add(lblCheckout);
		
		JLabel lblScegliLaData = new JLabel("Choose your date of stay");
		lblScegliLaData.setForeground(Color.WHITE);
		lblScegliLaData.setHorizontalAlignment(SwingConstants.CENTER);
		lblScegliLaData.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 43));
		lblScegliLaData.setBounds(116, 34, 668, 55);
		checkInCheckOut.add(lblScegliLaData);
		
		JLabel lblCheckin = new JLabel("Check-in");
		lblCheckin.setForeground(Color.WHITE);
		lblCheckin.setFont(new Font("SansSerif", Font.ITALIC, 31));
		lblCheckin.setBounds(201, 162, 135, 37);
		checkInCheckOut.add(lblCheckin);
		
		JButton btnAvanti = new JButton("Next");
		btnAvanti.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 13));
		btnAvanti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				if(dateChooser.getDate() == null || dateChooser_1.getDate() == null)
			          JOptionPane.showMessageDialog(null,"Please, insert check-in and ckeck-out date");
			    	else {
			          from = LocalDateTime.ofInstant(dateChooser.getDate().toInstant(), ZoneId.systemDefault());
			          to = LocalDateTime.ofInstant(dateChooser_1.getDate().toInstant(), ZoneId.systemDefault());
			          Duration d = Duration.between(from, to);
			          
			          if(d.toDays() <= 0)
			            JOptionPane.showMessageDialog(null,"Check-out date must be later than Check-in date");
			          else {			        	  
			        	  AppFrame.switchPanels(AppFrame.chooseVillaPanel);
			        	  AppFrame.lblChooseVilla.setBackground(Color.decode("#1976D2"));
			        	  AppFrame.lblCheckinCheckout.setBackground(Color.decode("#03A9F4"));
			          }
			        }
		     }
		});
		
	
	    btnAvanti.setBounds(772, 439, 90, 24);
	    checkInCheckOut.add(btnAvanti);
		
		dateChooser_1 = new JDateChooser();
		dateChooser_1.setMinSelectableDate(new Date());
		dateChooser_1.setBounds(521, 210, 217, 19);
		checkInCheckOut.add(dateChooser_1);
		
		dateChooser = new JDateChooser();
		dateChooser.setMinSelectableDate(new Date());
		dateChooser.setBounds(160, 210, 217, 19);
		checkInCheckOut.add(dateChooser);
		
		JLabel lblBackgroundimage = new JLabel();
		lblBackgroundimage.setBounds(0, 0, 900, 600);
		checkInCheckOut.add(lblBackgroundimage);
		lblBackgroundimage.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/30.jpg")).getImage().getScaledInstance(lblBackgroundimage.getWidth(), lblBackgroundimage.getHeight(), Image.SCALE_SMOOTH)));
	
		checkInCheckOut.setVisible(true);
		add(checkInCheckOut);
	}
	
}
