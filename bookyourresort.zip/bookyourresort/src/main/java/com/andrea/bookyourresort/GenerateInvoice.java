package com.andrea.bookyourresort;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfWriter;

/**
 *	This class generate the invoice to send to the customer
 */
public class GenerateInvoice {
 
 private BaseFont bfBold;
 private BaseFont bf;

public void createPDF (String pdfFilename){
	 
	  Document doc = new Document();
	  PdfWriter docWriter = null;
	  initializeFonts();
	 
	  try {
	   String path = "invoices/" + pdfFilename;
	   docWriter = PdfWriter.getInstance(doc , new FileOutputStream(path));
	   doc.addAuthor("betterThanZero");
	   doc.addCreationDate();
	   doc.addProducer();
	   doc.addCreator("MySampleCode.com");
	   doc.addTitle("Invoice "+pdfFilename);
	   doc.setPageSize(PageSize.LETTER);
	 
	   doc.open();
	   PdfContentByte cb = docWriter.getDirectContent();
	    
	   boolean beginPage = true;
	   int y = 0;
	    
	   
	    if(beginPage){
	     beginPage = false;
	     generateLayout(doc, cb); 
	     generateHeader(doc, cb);
	     y = 615; 
	  
	    generateDetail(doc, cb, y);
	    y = y - 15;
	    if(y < 50){
	     doc.newPage();
	     beginPage = true;
	    }
	   }
	  }
	  catch (DocumentException dex)
	  {
	   dex.printStackTrace();
	  }
	  catch (Exception ex)
	  {
	   ex.printStackTrace();
	  }
	  finally
	  {
	   if (doc != null)
	   {
	    doc.close();
	   }
	   if (docWriter != null)
	   {
	    docWriter.close();
	   }
	  }
	 }
	 
	 private void generateLayout(Document doc, PdfContentByte cb)  {
	 
	  try {
	 
	   cb.setLineWidth(1f);
	 
	   // Invoice Header box layout
	   cb.rectangle(410,700,160,60);
	   cb.moveTo(410,720);
	   cb.lineTo(570,720);
	   cb.moveTo(410,740);
	   cb.lineTo(570,740);
	   cb.moveTo(480,700);
	   cb.lineTo(480,760);
	   cb.stroke();
	 
	   // Invoice Header box Text Headings 
	   createHeadings(cb,412,743,"Account No.");
	   createHeadings(cb,412,723,"Invoice No.");
	   createHeadings(cb,412,703,"Invoice Date");
	 
	   // Invoice Detail box layout 
	   cb.moveTo(20,630);
	   cb.lineTo(570,630);
	   cb.stroke();
	   // Invoice Detail box Text Headings 
	   createBody(cb,22,633,"Name");
	   createBody(cb,300,633,"Email");
	   
	   cb.moveTo(20,530);
	   cb.lineTo(570,530);
	   cb.stroke();
	   createBody(cb,22,533,"Mobile");
	   createBody(cb,300,533,"Address");
	   
	   cb.moveTo(20,430);
	   cb.lineTo(570,430);
	   cb.stroke();
	   createBody(cb,22,433,"Activities");
	   
	   cb.moveTo(20,330);
	   cb.lineTo(570,330);
	   cb.stroke();
	   createBody(cb,22,333,"Check-in");
	   createBody(cb,300,333,"Check-out");
	   
	   cb.moveTo(20,230);
	   cb.lineTo(570,230);
	   cb.stroke();
	   createBody(cb,22,233,"Villa Type");
	   createBody(cb,300,233,"Price per night (in euro)");
	   
	   createBody(cb,450,133,"Ext Price");
	 
	   //add the images
	   Image companyLogo = Image.getInstance(this.getClass().getResource("/3.jpg"));
	   companyLogo.setAbsolutePosition(25,685);
	   companyLogo.scalePercent(25);
	   doc.add(companyLogo);
	 
	  }
	 
	  catch (DocumentException dex){
	   dex.printStackTrace();
	  }
	  catch (Exception ex){
	   ex.printStackTrace();
	  }
	 
	 }
	  
	 private void generateHeader(Document doc, PdfContentByte cb)  {
	 
	  try {
	 
	   createHeadings(cb,166,750,"Book Your Resort");
	   createHeadings(cb,166,735,"H.Sonary, 2nd Floor, BoduthakurufaanuMagu");
	   createHeadings(cb,166,720,"Malê, Maldives - 20026");   
	   createHeadings(cb,482,743,"ABC0001");
	   createHeadings(cb,482,723,"123456");
	   Date date = new Date();
	   String modifiedDate= new SimpleDateFormat("yyyy/MM/dd").format(date);
	   createHeadings(cb,482,703,modifiedDate);
	  }
	  
	  catch (Exception ex){
	   ex.printStackTrace();
	  }
	 
	 }
	  
	 private void generateDetail(Document doc, PdfContentByte cb,  int y)  {   
	  try {		  
		  
	   /* NAME EMAIL */
	   createContent(cb,22,y, Customer.name ,PdfContentByte.ALIGN_LEFT);
	   createContent(cb,300,y, Customer.email,PdfContentByte.ALIGN_LEFT);
	   
	   /* MOBILE ADDRESS */
	   createContent(cb,22,515, Customer.mobile,PdfContentByte.ALIGN_LEFT);
	   createContent(cb,300,515, Customer.address,PdfContentByte.ALIGN_LEFT);
	   
	   /* ACTIVITIES */
	   String activities = "";
	   String activities2 = "";
	   int cont = 0;
	   for (String rowData : Customer.getActivities()) {
		   if(cont <= 5)
			   activities += rowData+" - ";
		   else
			   activities2 += rowData+" - ";
		   
		   cont++;
		}
		if(!activities.equals(""))
			activities = activities.substring(0, activities.length() - 3);
		if(!activities2.equals(""))
			activities2 = activities2.substring(0, activities2.length() - 3);
		
	   createContent(cb,22,415, activities,PdfContentByte.ALIGN_LEFT);
	   createContent(cb,22,400, activities2,PdfContentByte.ALIGN_LEFT);
	    
	   /* CHECK-IN CHECK-OUT DATES */
	   SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy", Locale.ENGLISH);
	   SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
	   Date parsedCheckInDate = sdf.parse(Customer.checkIn.toString());
	   String checkIn = format.format(parsedCheckInDate);
   	
	   Date parsedCheckOutDate = sdf.parse(Customer.checkOut.toString());
	   String checkOut = format.format(parsedCheckOutDate);
	   
	   createContent(cb,22,315, checkIn,PdfContentByte.ALIGN_LEFT);
	   createContent(cb,300,315, checkOut,PdfContentByte.ALIGN_LEFT);
	   
	   /* VILLATYPE PRICE */
	   createContent(cb,22,215, Customer.villaType,PdfContentByte.ALIGN_LEFT);
	   createContent(cb,300,215, Double.toString(ChooseVillaPanel.concretevilla.getPrice()),PdfContentByte.ALIGN_LEFT);
	   
	   /* EXT PRICE */
	   LocalDateTime from = LocalDateTime.ofInstant(CheckInCheckOutPanel.dateChooser.getDate().toInstant(), ZoneId.systemDefault());
	   LocalDateTime to = LocalDateTime.ofInstant(CheckInCheckOutPanel.dateChooser_1.getDate().toInstant(), ZoneId.systemDefault());
       Duration d = Duration.between(from, to);
       
	   createContent(cb,450,115, Double.toString((ChooseVillaPanel.concretevilla.getPrice())*d.toDays()),PdfContentByte.ALIGN_LEFT);   
	  }
	 
	  catch (Exception ex){
	   ex.printStackTrace();
	  }
	 
	 }
	 
	 private void createHeadings(PdfContentByte cb, float x, float y, String text){
	 
	  cb.beginText();
	  cb.setFontAndSize(bfBold, 11);
	  cb.setTextMatrix(x,y);
	  cb.showText(text.trim());
	  cb.endText(); 
	 
	 }
	 
	 private void createBody(PdfContentByte cb, float x, float y, String text){
		 
	  cb.beginText();
	  cb.setFontAndSize(bfBold, 14);
	  cb.setTextMatrix(x,y);
	  cb.showText(text.trim());
	  cb.endText(); 
	 
	 }
	  
	 private void createContent(PdfContentByte cb, float x, float y, String text, int align){
		 
	  cb.beginText();
	  cb.setFontAndSize(bf, 14);
	  cb.showTextAligned(align, text.trim(), x , y, 0);
	  cb.endText(); 
	  
	 }
	 
	 private void initializeFonts(){
	 
	  try {
	   bfBold = BaseFont.createFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
	   bf = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
	 
	  } catch (DocumentException e) {
	   e.printStackTrace();
	  } catch (IOException e) {
	   e.printStackTrace();
	  }
		 
		 
		 }
		 
		}
	 