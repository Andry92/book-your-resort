package com.andrea.bookyourresort;
import java.util.*;

/**
 * Villa interface is a component interface used for defining the methods that will be implemented. 
 */
public interface Villa {

    /**
     * Declared the ArrayList variable villaActivity that contains all the possible villas activities. 
     */
    static ArrayList<String> villaActivity = new ArrayList<String>( Arrays.asList("Holistic Massage", "Pilates", "Zumba", "Golf", "Excursion", "Yoga") );

    /**
     * This method add the customer.
     * @param userEmail string that represents the customer's email
     * @param VillaType string that represents the type of villa chosen by the customer
     */
    public void addCustomer(String userEmail, String VillaType);

    /**
     * This method sends email to all followers of the villa type.
     * 
     */
    public void sendMessage();

    

}