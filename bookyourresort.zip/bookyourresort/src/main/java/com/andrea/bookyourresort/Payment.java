package com.andrea.bookyourresort;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import com.toedter.calendar.JYearChooser;
import com.toedter.calendar.JMonthChooser;
import java.util.List;

/**
 * Payment class.
 *
 */
public class Payment extends JPanel { 
	  
// Components of the Form 
private JPanel p; 
private JLabel title; 
private JRadioButton CC ;
private JRadioButton PP;
private JLabel lblEmailPP;
private JTextField temailPP;
private JTextField numberField;
private JLabel validLabel;
private JButton verifyButton;
private JLabel lblPassword;
private JTextField tPassword;
private JTextField tnameOnCard;
private JTextField tcvv;
private final ButtonGroup buttonGroup = new ButtonGroup();

static PaymentContext paymentContext;
static PaypalStrategy paypalStrategy;
static CardStrategy cardStrategy;

 
    /**
     * Payment constructor, to initialize the components with default values. 
     * 
     */
    public Payment() 
    {
    	
    	p=new JPanel();
    	setBounds(0, 83, 900, 600);
    	p.setPreferredSize(new Dimension(900, 600));
    	p.setLayout(null); 
        
        JYearChooser yearChooser = new JYearChooser();
        yearChooser.getSpinner().setFont(new Font("SansSerif", Font.BOLD, 15));
        yearChooser.setBounds(594, 293, 65, 29);
        p.add(yearChooser);
        
        JMonthChooser monthChooser = new JMonthChooser();
        monthChooser.setBounds(470, 293, 95, 29);
        p.add(monthChooser);
       
        
        validLabel = new JLabel("");
        validLabel.setForeground(Color.WHITE);
        validLabel.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 20)); 
        validLabel.setSize(169, 24); 
        validLabel.setLocation(504, 216); 
        p.add(validLabel);
        
        
        numberField = new JTextField(16);
        numberField .setFont(new Font("Arial", Font.PLAIN, 15)); 
        numberField .setSize(223, 20); 
        numberField .setLocation(470, 185); 
        p.add(numberField);
        
        JLabel ccNumber = new JLabel("Card Number"); 
        ccNumber .setForeground(Color.WHITE);
        ccNumber .setFont(new Font("SansSerif", Font.BOLD, 25)); 
        ccNumber .setSize(166, 29); 
        ccNumber .setLocation(472, 145); 
        p.add(ccNumber );
        
        JLabel expirationDate = new JLabel("Expiration Date"); 
        expirationDate .setForeground(Color.WHITE);
        expirationDate .setFont(new Font("SansSerif", Font.BOLD, 25)); 
        expirationDate.setSize(203, 32); 
        expirationDate.setLocation(470, 250); 
        p.add(expirationDate );
        
        JLabel cvv = new JLabel("CVV"); 
        cvv .setForeground(Color.WHITE);
        cvv .setFont(new Font("SansSerif", Font.BOLD, 25)); 
        cvv .setSize(65, 29); 
        cvv .setLocation(470, 331); 
        p.add(cvv);
        
        tcvv = new JTextField(); 
        tcvv.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tcvv.setSize(75, 20); 
        tcvv.setLocation(470, 371); 
        p.add(tcvv); 
        
        JLabel nameOnCard = new JLabel("Name On Card"); 
        nameOnCard.setForeground(Color.WHITE);
        nameOnCard.setFont(new Font("SansSerif", Font.BOLD, 25)); 
        nameOnCard.setSize(180, 29); 
        nameOnCard.setLocation(470, 402); 
        p.add(nameOnCard);
        
        tnameOnCard = new JTextField(); 
        tnameOnCard.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tnameOnCard.setSize(223, 20); 
        tnameOnCard.setLocation(470, 442); 
        p.add(tnameOnCard); 
        
        verifyButton = new JButton("Verify");
        verifyButton.setFont(new Font("SansSerif", Font.BOLD, 13));
        verifyButton.setBounds(698, 181, 73, 24);
        p.add(verifyButton);
       
        verifyButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        			String text = numberField.getText();
        			if (CardStrategy.isValidCC(text)) {
        				validLabel.setText("Valid number!");
        			} else {
        				validLabel.setText("Invalid number.");
            		}
           	}
        });
        
        JButton button_2 = new JButton("Back");
        button_2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            AppFrame.switchPanels(AppFrame.customerFormPanel);
            AppFrame.lblPaymentForm.setBackground(Color.decode("#03A9F4"));
            AppFrame.lblCustomerForm.setBackground(Color.decode("#1976D2"));
            
            CustomerForm.tout.setText("");
          }
        });
        button_2.setFont(new Font("SansSerif", Font.BOLD, 14));
        button_2.setBounds(12, 439, 98, 24);
        p.add(button_2);
  
        title = new JLabel("Choose Payment Method"); 
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 43)); 
        title.setSize(537, 55); 
        title.setLocation(181, 11); 
        p.add(title);
        
        CC = new JRadioButton("Credit Card");
        CC.setForeground(Color.WHITE);
        buttonGroup.add(CC);
        CC.setOpaque(false);
        CC.setFont(new Font("SansSerif", Font.BOLD, 25));
        CC.setSize(168, 29); 
        CC.setLocation(525, 95); 
        p.add(CC); 
        
        CC.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ButtonModel buttonModel = buttonGroup.getSelection();
                
                if (buttonModel != null) {
                  numberField.setEnabled(true);
                  monthChooser.setEnabled(true);
                  yearChooser.setEnabled(true);
                  tcvv.setEnabled(true);
                  tnameOnCard.setEnabled(true);
                  verifyButton.setEnabled(true);
                  
                temailPP.setEnabled(false);
                tPassword.setEnabled(false);
                }
              }
        });
  
        PP = new JRadioButton("Paypal");
        PP.setForeground(Color.WHITE);
        PP.setOpaque(false);
        buttonGroup.add(PP);
        PP.setFont(new Font("SansSerif", Font.BOLD, 25));
        PP.setSize(107, 29); 
        PP.setLocation(126, 95); 
        p.add(PP); 
        
        PP.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ButtonModel buttonModel = buttonGroup.getSelection();
                
               if (buttonModel != null) {
                  temailPP.setEnabled(true);
                  tPassword.setEnabled(true);
                  
                numberField.setEnabled(false);
                monthChooser.setEnabled(false);
                yearChooser.setEnabled(false);
                tcvv.setEnabled(false);
                tnameOnCard.setEnabled(false);
                verifyButton.setEnabled(false);
                }
              }
          });
        
        lblEmailPP = new JLabel("Email");
        lblEmailPP.setFont(new Font("SansSerif", Font.BOLD, 25));
        lblEmailPP.setForeground(Color.WHITE);
        lblEmailPP.setBounds(94, 185, 75, 29);
        p.add(lblEmailPP);
        
        temailPP = new JTextField();
        temailPP.setBackground(Color.WHITE);
        temailPP.setFont(new Font("Arial", Font.PLAIN, 15)); 
        temailPP.setSize(223, 20); 
        temailPP.setLocation(94, 235); 
        p.add(temailPP); 
        
        lblPassword = new JLabel("Password");
        lblPassword.setFont(new Font("SansSerif", Font.BOLD, 25));
        lblPassword.setForeground(Color.WHITE);
        lblPassword.setBounds(94, 266, 139, 29);
        p.add(lblPassword);
        
        tPassword = new JTextField();
        tPassword.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tPassword.setSize(223, 20); 
        tPassword.setLocation(94, 314); 
        p.add(tPassword); 
        
        JButton confirm = new JButton("Confirm");
        confirm.setFont(new Font("SansSerif", Font.BOLD, 14));
        confirm.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	
	        	if(!PP.isSelected() && !CC.isSelected())
	        		JOptionPane.showMessageDialog(null,"Please, select method payment");
	        	else
	        	if(PP.isSelected() && (temailPP.getText().equals("") || tPassword.getText().equals(""))) {
	        		JOptionPane.showMessageDialog(null,"Please, insert email and password");
	        	}
	        	else
	        	if(CC.isSelected() && (numberField.getText().equals("") || tcvv.getText().equals("") 
	        			|| tnameOnCard.getText().equals(""))) {
	        		JOptionPane.showMessageDialog(null,"Please, insert Card Number, Expiration Date, CVV and Name on Card");
	        	}
	        	else {
	        		if(PP.isSelected()) {
	        			paymentContext = new PaymentContext();
	        			paypalStrategy = new PaypalStrategy(temailPP.getText(), tPassword.getText() );
	        			paymentContext.setPaymentStrategy(paypalStrategy);
	        		}
	        		else {
	        			paymentContext = new PaymentContext();
	        			String expirationDate = monthChooser.toString()+"/"+yearChooser.toString();
	        			cardStrategy = new CardStrategy(tnameOnCard.getText(), numberField.getText(), tcvv.getText(), expirationDate);
	        			paymentContext.setPaymentStrategy(cardStrategy);
	        		}
	        		
	        		int choice = JOptionPane.showConfirmDialog(null, "Are you sure to proceed with payment?");
		        	if(choice==JOptionPane.YES_OPTION) {
		        		boolean customerAdded;
		        		
		        		List<String> rowsCustomer = Arrays.asList(Customer.name, Customer.email, Customer.checkIn.toString(), Customer.checkOut.toString(), Customer.villaType);
		        		
			        	customerAdded = CsvUtilities.addLinesToCSVCustomers(rowsCustomer);
		        		if(customerAdded) {
		        			paymentContext.pay();
		        			
		        			button_2.setEnabled(false);
		        			confirm.setEnabled(false);
		        			
		        			ChooseVillaPanel.concretevilla.deleteCustomer(Customer.email);
		        			
		        			if(Customer.villaType.equals(ChooseVillaPanel.concretevilla.getType()))
		        				ChooseVillaPanel.concretevilla.sendMessage();
		        			else 
		        				ChooseVillaPanel.piscinadecorator.sendMessage();
		        			
		        			String subject = "Booking of Villa";
		    				String body = "Dear "+Customer.name+","
		    						+ "\n\nThank you for your reservation in Book Your Resort."
		    						+ "\nFind attached to this mail a copy of your invoice."
		    						+ "\n\nBest regards,\nBook Your Resort Staff";
		        			
		        			boolean invoiceSent = SendEmail.SendInvoiceToCustomer(Customer.email, Customer.name, subject, body);
		        			if(invoiceSent)
		        				JOptionPane.showMessageDialog(null, "We sent the invoice to your email!");
		        			else
		        				JOptionPane.showMessageDialog(null, "Error sending invoice to your email. We'll send it later.");		        				
		        		}
		        		else
		        			JOptionPane.showMessageDialog(null, "Payment Failed");
		        	
		        	}
		        	else if(choice==JOptionPane.NO_OPTION) 
		        		JOptionPane.showMessageDialog(null, "Payment Failed");
	        	}	        	
	        }
		});
        confirm.setBounds(772, 439, 90, 24);
        p.add(confirm);
        
       JLabel lblBackgroundimage_3 = new JLabel("");
       lblBackgroundimage_3.setBounds(0, 0, 900, 543);
       p.add(lblBackgroundimage_3);
       lblBackgroundimage_3.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/30.jpg")).getImage().getScaledInstance(lblBackgroundimage_3.getWidth(), lblBackgroundimage_3.getHeight(), Image.SCALE_SMOOTH)));
  
       
        add(p);
    }
   
 }
    

