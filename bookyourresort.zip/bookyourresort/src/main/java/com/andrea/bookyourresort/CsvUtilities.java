package com.andrea.bookyourresort;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CsvUtilities {

	/**
    * This method is used to add Customers in customers csv file.
    * @param rowsCustomer data to be entered in customers csv file.
    * @return boolean if list of data is successfully added.
    */
	public static boolean addLinesToCSVCustomers(List<String> rowsCustomer) {
		try {
			File csv = new File("data/customers.csv");
			if (!csv.exists()){
			    FileWriter csvCustomers= new FileWriter(csv);
			    
			    csvCustomers.append("ID");
			    csvCustomers.append(",");
			    csvCustomers.append("Name");
			    csvCustomers.append(",");
			    csvCustomers.append("Email");
			    csvCustomers.append(",");
			    csvCustomers.append("Check-in");
			    csvCustomers.append(",");
			    csvCustomers.append("Check-out");
			    csvCustomers.append(",");
			    csvCustomers.append("VillaType");
			    csvCustomers.append("\n");
			    
			    csvCustomers.append("0");
			    csvCustomers.append(",");
			    
			    csvCustomers.append(rowsCustomer.stream().collect(Collectors.joining(",")));
			    csvCustomers.append("\n");

				csvCustomers.flush();
				csvCustomers.close();
				
				return true;
			}
			else {
				FileWriter csvCustomers = new FileWriter(csv, true);
				BufferedReader csvCustomersReader = new BufferedReader(new FileReader(csv));
				
				String row;
				String[] dataReader = null;
				while ((row = csvCustomersReader.readLine()) != null) {
					dataReader = row.split(",");
				}
				int id = Integer.parseInt(dataReader[0])+1;
				
				csvCustomers.append(Integer.toString(id));
			    csvCustomers.append(",");
			    csvCustomers.append(rowsCustomer.stream().collect(Collectors.joining(",")));
				csvCustomers.append("\n");

				csvCustomersReader.close();
				csvCustomers.flush();
				csvCustomers.close();
				
				return true;
			}
		} catch (IOException e) {
           
            return false;
        }
	}
	
	
	/**
	    * This method is used to add Followers in followers csv file.
	    * @param data data to be entered in followers csv file.
	    * @return boolean if list of data is successfully added.
	    */
	public static boolean addLinesToCSVFollowers(List<String> data) {
		try {
			File csv = new File("data/followers.csv");
			if (!csv.exists()){
			    FileWriter csvFollowers = new FileWriter(csv);
			    
			    csvFollowers.append("Email");
				csvFollowers.append(",");
				csvFollowers.append("Type");
				csvFollowers.append("\n");

				csvFollowers.append(data.stream().collect(Collectors.joining(",")));
				csvFollowers.append("\n");

				csvFollowers.flush();
				csvFollowers.close();
				return true;
			}
			else {
				FileWriter csvFollowers = new FileWriter(csv, true);

				csvFollowers.append(data.stream().collect(Collectors.joining(",")));
				csvFollowers.append("\n");

				csvFollowers.flush();
				csvFollowers.close();
				return true;
			}
		} catch (IOException e) {
           
            return false;
        }
	}
	
	/**
	    * This method is used to check if email's customer exists in followers csv file.
	    * @param email customer's email to check in csv followers file. 
	    * @return boolean boolean value to confirm if email exists.
	    */
	public static boolean checkIfEmailExists(String email) {
		try {
			File csv = new File("data/followers.csv");
			if (csv.isFile()) {
				BufferedReader csvFollowers = new BufferedReader(new FileReader(csv));
				String row;
				boolean emailExists = false;
				
				while ((row = csvFollowers.readLine()) != null) {
				    String[] data = row.split(",");
				    if(data[0].equals(email))
				    	emailExists = true;
				}
				
				csvFollowers.close();
				return emailExists;
			}
			else
	            return false;
		} catch (IOException e1) {
           
            return false;
        }
	}
	
	/**
    * This method is used to get Followers of that Villa type in followers csv file.
    * @param villaType data to be entered in followers csv file.
    * @return String email to send mail to.
    */
	public static String getEmailsVillaType(String villaType) {
		
			String emails = "";
			
			File csv = new File("data/followers.csv");
			if (csv.isFile()) {
				
				List<List<String>> followers = importDataFromCsv("data/followers.csv");
				
				for (List<String> rowData : followers) {
					String[] data = rowData.get(0).split(",");
					
					if(villaType.equals(data[1])) {
						emails += data[0]+", ";
					}
				}
				
				if(!emails.equals(""))
					emails = emails.substring(0, emails.length() - 2);
				
			}
			
			return emails;
			
	}
	
	/**
	    * This method is used to check the number of busy Villa type in customers csv file considering the check-in and check-out dates inserted by the user.
	    * @param checkIn check-in date inserted by the user.
	    * @param checkOut check-out date inserted by the user.
	    * @param villaType villa's type chosen by the user.
	    * @return Integer the number of busy villas.
	    */
	public static Integer checkIfResortIsBusy(String checkIn, String checkOut, String villaType) {
		
        try {
        	SimpleDateFormat parser = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy", Locale.ENGLISH);
        	Date checkin = parser.parse(checkIn);
			Date checkout = parser.parse(checkOut);
			
			int cont = 0;
			
			File csv = new File("data/customers.csv");
			if (csv.exists()){
				List<List<String>> values = importDataFromCsv("data/customers.csv");
				
					for (List<String> rowData : values) {
						String[] data = rowData.get(0).split(",");
						
						if(villaType.equals(data[5])) {
							Date checkinFile = parser.parse(data[3]);
							Date checkoutFile = parser.parse(data[4]);
							
							// check if checkin or checkout is in range (range is included) or Range is in range
							if((checkinFile.compareTo(checkin) * checkin.compareTo(checkoutFile) >= 0) ||
									(checkinFile.compareTo(checkout) * checkout.compareTo(checkoutFile) >= 0) ||
									(checkinFile.before(checkout) && checkin.before(checkoutFile)))
								cont++;
						}
				}
			}
					
			return cont;
			
		} catch (ParseException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	/**
	    * This method is used to delete email from csv followers file if customer was a follower.
	    * @param email customer's email to delete in csv followers file 
	    * @return boolean boolean value to confirm if email was deleted.
	    */
	public static boolean deleteEmailToCSVFollowers(String email) {
		
		try {
		
			File followers = new File("data/followers.csv");
			File newFollowers = new File("data/followers.csv");
			if (followers.exists()){
				List<List<String>> values = importDataFromCsv("data/followers.csv");
				
				FileWriter csvFollowers = new FileWriter(newFollowers);
				
				csvFollowers.append("Email");
				csvFollowers.append(",");
				csvFollowers.append("Type");
				csvFollowers.append("\n");
				
				for (List<String> rowData : values) {
					String[] data = rowData.get(0).split(",");
					
					if(!email.equals(data[0])) {
						csvFollowers.append(rowData.stream().collect(Collectors.joining(",")));
						csvFollowers.append("\n");
					}
				}
			
				csvFollowers.flush();
				csvFollowers.close();
				return true;
			}
			else
				return false;
		
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * This method allows you to import all CSV data except the first line (which is assumed to be the set of file headers).
	 * 
	 * @param filePath CSV file path from which to import data
	 * @return the set of records in the csv file excluding the first
	 */
	public static List<List<String>> importDataFromCsv(String filePath) {     
        
        List<List<String>> values = new ArrayList<>();
        
        try (Stream<String> stream = Files.lines(Paths.get(filePath))) {
            values = stream.skip(1).map(line -> Arrays.asList(line.split(";"))).collect(Collectors.toList()); 
        } catch (IOException e) {
            e.printStackTrace();
        }
        return values;
    }
	
}
