package com.andrea.bookyourresort;

import javax.swing.*;

import com.andrea.bookyourresort.Shape;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * ChooseActivities Class.
 */
public class ChooseActivitiesPanel extends JPanel {

	JPanel chooseActivities;
	
	/* Activities */
	static JCheckBox chckbxAquaTabata;
	static JCheckBox chckbxHydrobike;
	static JCheckBox chckbxAcquagym;
	static JCheckBox chckbxWoga;
	static JCheckBox chckbxSwimmingPoolGames;
	static JCheckBox chckbxYoga;
	static JCheckBox chckbxExcursion;
	static JCheckBox chckbxHolisticMassage;
	static JCheckBox chckbxPilates;
	static JCheckBox chckbxZumba;
	static JCheckBox chckbxGolf;
	
	/**
     * Constructor of ChooseActivities class that create a new JPanel.
    */
	public ChooseActivitiesPanel() {
		chooseActivities = new JPanel();
		chooseActivities.setBackground(new Color(240, 255, 255));
		setBounds(0, 83, 900, 600);
		chooseActivities.setPreferredSize(new Dimension(900, 600));
		chooseActivities.setLayout(null);
	
	
		/* VILLA WITH SWIMMING POOL ACTIVITIES */
		chckbxAquaTabata = new JCheckBox(PiscinaDecorator.piscinaActivity.get(2));
		chckbxAquaTabata.setVisible(false);
		chckbxAquaTabata.setOpaque(false);
		chckbxAquaTabata.setForeground(Color.WHITE);
		chckbxAquaTabata.setFont(new Font("SansSerif", Font.BOLD, 22));
		chckbxAquaTabata.setBackground(SystemColor.activeCaption);
		chckbxAquaTabata.setBounds(423, 246, 172, 33);
		chooseActivities.add(chckbxAquaTabata);
		chckbxAquaTabata.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxAquaTabata.isSelected())

				Customer.setActivities(chckbxAquaTabata.getText());
		    }
		});
		
		chckbxSwimmingPoolGames = new JCheckBox(PiscinaDecorator.piscinaActivity.get(4));
		chckbxSwimmingPoolGames.setVisible(false);
		chckbxSwimmingPoolGames.setOpaque(false);
		chckbxSwimmingPoolGames.setForeground(Color.WHITE);
		chckbxSwimmingPoolGames.setFont(new Font("SansSerif", Font.BOLD, 22));
		chckbxSwimmingPoolGames.setBackground(SystemColor.activeCaption);
		chckbxSwimmingPoolGames.setBounds(597, 246, 281, 33);
		chooseActivities.add(chckbxSwimmingPoolGames);
		chckbxSwimmingPoolGames.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxSwimmingPoolGames.isSelected())

					Customer.setActivities(chckbxSwimmingPoolGames.getText());
		    }
		});
		
		chckbxHydrobike = new JCheckBox(PiscinaDecorator.piscinaActivity.get(1));
		chckbxHydrobike.setVisible(false);
		chckbxHydrobike.setOpaque(false);
		chckbxHydrobike.setForeground(Color.WHITE);
		chckbxHydrobike.setFont(new Font("SansSerif", Font.BOLD, 22));
		chckbxHydrobike.setBackground(SystemColor.activeCaption);
		chckbxHydrobike.setBounds(273, 246, 145, 33);
		chooseActivities.add(chckbxHydrobike);
		chckbxHydrobike.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxHydrobike.isSelected())

					Customer.setActivities(chckbxHydrobike.getText());
		    }
		});
		
		
		chckbxAcquagym = new JCheckBox(PiscinaDecorator.piscinaActivity.get(0));
		chckbxAcquagym.setVisible(false);
		chckbxAcquagym.setOpaque(false);
		chckbxAcquagym.setForeground(Color.WHITE);
		chckbxAcquagym.setFont(new Font("SansSerif", Font.BOLD, 22));
		chckbxAcquagym.setBackground(SystemColor.activeCaption);
		chckbxAcquagym.setBounds(124, 246, 159, 33);
		chooseActivities.add(chckbxAcquagym);
		chckbxAcquagym.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxAcquagym.isSelected())

					Customer.setActivities(chckbxAcquagym.getText());
		    }
		});
		
		chckbxWoga = new JCheckBox(PiscinaDecorator.piscinaActivity.get(3));
		chckbxWoga.setVisible(false);
		chckbxWoga.setOpaque(false);
		chckbxWoga.setForeground(Color.WHITE);
		chckbxWoga.setFont(new Font("SansSerif", Font.BOLD, 22));
		chckbxWoga.setBackground(SystemColor.activeCaption);
		chckbxWoga.setBounds(23, 246, 98, 33);
		chooseActivities.add(chckbxWoga);
		chckbxWoga.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxWoga.isSelected())

					Customer.setActivities(chckbxWoga.getText());
		    }
		});
		
		/* STANDARD VILLA ACTIVITIES */
		chckbxYoga = new JCheckBox(Villa.villaActivity.get(5));
		chckbxYoga.setOpaque(false);
		chckbxYoga.setForeground(Color.WHITE);
		chckbxYoga.setFont(new Font("SansSerif", Font.BOLD, 23));
		chckbxYoga.setBackground(SystemColor.activeCaption);
		chckbxYoga.setBounds(716, 157, 112, 33);
		chooseActivities.add(chckbxYoga);
		chckbxYoga.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxYoga.isSelected())

					Customer.setActivities(chckbxYoga.getText());
		    }
		});
		
		chckbxExcursion = new JCheckBox(Villa.villaActivity.get(4));
		chckbxExcursion.setOpaque(false);
		chckbxExcursion.setForeground(Color.WHITE);
		chckbxExcursion.setFont(new Font("SansSerif", Font.BOLD, 23));
		chckbxExcursion.setBackground(SystemColor.activeCaption);
		chckbxExcursion.setBounds(569, 156, 145, 35);
		chooseActivities.add(chckbxExcursion);
		chckbxExcursion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxExcursion.isSelected())

					Customer.setActivities(chckbxExcursion.getText());
		    }
		});
		
		chckbxHolisticMassage = new JCheckBox(Villa.villaActivity.get(0));
		chckbxHolisticMassage.setOpaque(false);
		chckbxHolisticMassage.setBackground(SystemColor.activeCaption);
		chckbxHolisticMassage.setForeground(Color.WHITE);
		chckbxHolisticMassage.setFont(new Font("SansSerif", Font.BOLD, 22));
		chckbxHolisticMassage.setBounds(51, 158, 202, 33);
		chooseActivities.add(chckbxHolisticMassage);
		chckbxHolisticMassage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxHolisticMassage.isSelected())

					Customer.setActivities(chckbxHolisticMassage.getText());
		    }
		});
		
		chckbxPilates = new JCheckBox(Villa.villaActivity.get(1));
		chckbxPilates.setOpaque(false);
		chckbxPilates.setBackground(SystemColor.activeCaption);
		chckbxPilates.setForeground(Color.WHITE);
		chckbxPilates.setFont(new Font("SansSerif", Font.BOLD, 23));
		chckbxPilates.setBounds(255, 160, 112, 31);
		chooseActivities.add(chckbxPilates);
		chckbxPilates.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxPilates.isSelected())

					Customer.setActivities(chckbxPilates.getText());
		    }
		});
		
		chckbxZumba = new JCheckBox(Villa.villaActivity.get(2));
		chckbxZumba.setOpaque(false);
		chckbxZumba.setBackground(SystemColor.activeCaption);
		chckbxZumba.setForeground(Color.WHITE);
		chckbxZumba.setFont(new Font("SansSerif", Font.BOLD, 23));
		chckbxZumba.setBounds(369, 158, 112, 33);
		chooseActivities.add(chckbxZumba);
		chckbxZumba.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxZumba.isSelected())

					Customer.setActivities(chckbxZumba.getText());
		    }
		});
		
		chckbxGolf = new JCheckBox(Villa.villaActivity.get(3));
		chckbxGolf.setOpaque(false);
		chckbxGolf.setBackground(SystemColor.activeCaption);
		chckbxGolf.setForeground(Color.WHITE);
		chckbxGolf.setFont(new Font("SansSerif", Font.BOLD, 23));
		chckbxGolf.setBounds(483, 156, 79, 36);
		chooseActivities.add(chckbxGolf);
		chckbxGolf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxGolf.isSelected())
					Customer.setActivities(chckbxGolf.getText());
		    }
		});
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 13));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int choice;
		        
		        if(chckbxAquaTabata.isSelected() || chckbxHydrobike.isSelected() || chckbxAcquagym.isSelected() || 
		            chckbxWoga.isSelected() || chckbxSwimmingPoolGames.isSelected() || chckbxYoga.isSelected() || 
		            chckbxExcursion.isSelected() || chckbxHolisticMassage.isSelected() || chckbxPilates.isSelected() || 
		            chckbxZumba.isSelected() || chckbxGolf.isSelected()) {
		          
		          choice = JOptionPane.showConfirmDialog(null, "Are you sure you don't want to choose another activity?", null, JOptionPane.YES_NO_OPTION);
		              if(choice==JOptionPane.YES_OPTION) {
		                AppFrame.switchPanels(AppFrame.customerFormPanel);
		                AppFrame.lblCustomerForm.setBackground(Color.decode("#1976D2"));
		                AppFrame.lblChooseActivity.setBackground(Color.decode("#03A9F4"));
		              }
		        }
		        else {
		          choice = JOptionPane.showConfirmDialog(null, "Are you sure you don't want to choose at least an activity?", null, JOptionPane.YES_NO_OPTION);
		              if(choice==JOptionPane.YES_OPTION) {
		            	AppFrame.switchPanels(AppFrame.customerFormPanel);
		            	AppFrame.lblCustomerForm.setBackground(Color.decode("#1976D2"));
		            	AppFrame.lblChooseActivity.setBackground(Color.decode("#03A9F4"));
		              }
		        
		        }
		    }
		});
		btnNewButton.setBounds(772, 439, 90, 24);
		chooseActivities.add(btnNewButton);
		
		JLabel lblScegliLeAttivit = new JLabel("Choose the activities");
		lblScegliLeAttivit.setForeground(Color.WHITE);
		lblScegliLeAttivit.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 43));
		lblScegliLeAttivit.setBounds(226, 27, 448, 45);
		chooseActivities.add(lblScegliLeAttivit);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 13));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				
				ChooseVillaPanel.buttonGroup.clearSelection();
				
				ChooseVillaPanel.tVilla.setVisible(false);
				ChooseVillaPanel.tVillaP.setVisible(false);
				
				AppFrame.switchPanels(AppFrame.chooseVillaPanel);
				AppFrame.lblChooseVilla.setBackground(Color.decode("#1976D2"));
				AppFrame.lblChooseActivity.setBackground(Color.decode("#03A9F4"));
				
				chckbxAquaTabata.setSelected(false);
				chckbxHydrobike.setSelected(false);
				chckbxAcquagym.setSelected(false);
				chckbxWoga.setSelected(false);
				chckbxSwimmingPoolGames.setSelected(false);
				chckbxYoga.setSelected(false);
				chckbxExcursion.setSelected(false);
				chckbxHolisticMassage.setSelected(false);
				chckbxPilates.setSelected(false);
				chckbxZumba.setSelected(false);
				chckbxGolf.setSelected(false);
		      }
		});
		btnBack.setBounds(12, 439, 98, 24);
		chooseActivities.add(btnBack);
		
		JLabel lblBackgroundimage_2 = new JLabel("");
		lblBackgroundimage_2.setBounds(0, 0, 900, 600);
		chooseActivities.add(lblBackgroundimage_2);
		lblBackgroundimage_2.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/30.jpg")).getImage().getScaledInstance(lblBackgroundimage_2.getWidth(), lblBackgroundimage_2.getHeight(), Image.SCALE_SMOOTH)));
	
		chooseActivities.setVisible(true);
		add(chooseActivities);
	
	}
	
}
