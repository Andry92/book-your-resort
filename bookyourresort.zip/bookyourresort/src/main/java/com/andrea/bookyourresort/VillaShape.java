package com.andrea.bookyourresort;

import java.awt.Color;
import java.awt.Graphics;


/**
 * VillaShape class. In this class we draw the pool shape.
 *
 */
public class VillaShape implements Shape {

	private boolean busy;
	
	/**
	 * Constructor of the VillaShape class.
	 * 
	 * @param b boolean value to check if the villa is busy.
	 */
	public VillaShape(boolean b){
		this.busy=b;
	}
	

	/**
	 * This method draw the villa shape using x,y coordinates.
	 * 
	 * @param rect a Graphics object of the Graphics class.
	 * @param x x coordinate of pool shape.
	 * @param y y coordinate of pool shape.
	 * @param width width of pool shape.
	 * @param height height of pool shape.
	 */
	@Override
	public void draw(Graphics rect, int x, int y, int width, int height) {
		if(busy){
			rect.setColor(Color.RED);
			rect.fillRect(x, y, width, height);
	    }
	    else {
	    	rect.setColor(Color.BLUE);
	    	rect.fillRect(x, y, width, height);
	    }
	}

}
