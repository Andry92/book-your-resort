package com.andrea.bookyourresort;

import java.util.HashMap;

/**
 * ShapeFactory class. This class is used to add shapes element to HashMap.
 *
 */
public class ShapeFactory {

	private static final HashMap<ShapeType,Shape> shapes = new HashMap<ShapeType,Shape>();

	/**
	 * This method get the interface Shape object.
	 * 
	 * @param type the shape type (rectangle or oval).
	 * @return Shape interface Shape object.
	 */
	public static Shape getShape(ShapeType type) {
		Shape shapeImpl = shapes.get(type);

		if (shapeImpl == null) {
			if (type.equals(ShapeType.RECTP_BLUE)) {
				shapeImpl = new VillaShape(false);
				shapes.put(type, shapeImpl);
			}
			else if (type.equals(ShapeType.RECTP_RED)) {
				shapeImpl = new VillaShape(true);
				shapes.put(type, shapeImpl);
			}
			else if (type.equals(ShapeType.RECT_BLUE)) {
				shapeImpl = new VillaShape(false);
				shapes.put(type, shapeImpl);
			}
			else if (type.equals(ShapeType.RECT_RED)) {
				shapeImpl = new VillaShape(true);
				shapes.put(type, shapeImpl);
			}else if (type.equals(ShapeType.OVAL_BLUE)) {
				shapeImpl = new PiscinaShape(false);
				shapes.put(type, shapeImpl);
			}else if (type.equals(ShapeType.OVAL_RED)) {
				shapeImpl = new PiscinaShape(true);
				shapes.put(type, shapeImpl);
			}
			
		}
		return shapeImpl;
	}
	
	public static enum ShapeType{
		RECT_BLUE, RECT_RED, RECTP_BLUE, RECTP_RED, OVAL_RED, OVAL_BLUE;
	}
}
