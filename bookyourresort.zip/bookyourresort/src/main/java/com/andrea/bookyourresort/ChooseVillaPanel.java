package com.andrea.bookyourresort;

import javax.swing.*;
import javax.swing.border.LineBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * ChooseVilla Class.
 */
public class ChooseVillaPanel extends JPanel{

	JPanel chooseVilla;
	static JTextArea tVilla;
	static JTextArea tVillaP;
	
	static JPanel grid;
	
	static ConcreteVilla concretevilla;
	static ConcretePiscinaDecorator concretepiscinadecorator;
	static PiscinaDecorator piscinadecorator;
	
	/* bottoni selezione villa con piscina o senza */
	static JRadioButton rdbtnVillaSenzaPiscina;
	static JRadioButton rdbtnVillaConPiscina;
	
	static final ButtonGroup buttonGroup = new ButtonGroup();
	
	/**
     * Constructor of ChooseVilla class that create a new JPanel.
    */
	public ChooseVillaPanel() {
		chooseVilla = new JPanel();
		chooseVilla.setBackground(new Color(240, 255, 255));
		setBounds(0, 83, 900, 600);
		chooseVilla.setPreferredSize(new Dimension(900, 600));
		chooseVilla.setLayout(null); 
		
		tVillaP = new JTextArea("Price (per night): 3.720 euro");
	    tVillaP.setForeground(Color.WHITE);
	    tVillaP.setEditable(false);
	    tVillaP.setLineWrap(true);
	    tVillaP.setFont(new Font("SansSerif", Font.PLAIN, 19)); 
	    tVillaP.setSize(254, 32); 
	    tVillaP.setLocation(531, 334);
	    tVillaP.setBackground(Color.decode("#1976D2"));
	    tVillaP.setVisible(false);
	      
	    tVilla = new JTextArea("Price (per night): 2.500 euro"); 
	    tVilla.setForeground(Color.WHITE);
	    tVilla.setFont(new Font("SansSerif", Font.PLAIN, 19)); 
	    tVilla.setSize(246, 32); 
	    tVilla.setLocation(145, 334); 
	    tVilla.setLineWrap(true); 
	    tVilla.setEditable(false);
	    tVilla.setBackground(Color.decode("#1976D2"));
	    tVilla.setVisible(false);
	    chooseVilla.add(tVilla);
	    chooseVilla.add(tVillaP);
	     
	    grid = new JPanel();
	    grid.setOpaque(false);
	    grid.setBounds(53, 70, 793, 197);
	    chooseVilla.add(grid);
	     
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBorder(new LineBorder(new Color(255, 255, 255), 2));
		lblNewLabel.setBounds(53, 70, 793, 197);
		chooseVilla.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBackground(Color.WHITE);
		separator.setForeground(Color.WHITE);
		separator.setBounds(64, 152, 771, 2);
		chooseVilla.add(separator);
		
		JButton btnNewButton_1 = new JButton("Follow");
		btnNewButton_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!rdbtnVillaConPiscina.isSelected() && !rdbtnVillaSenzaPiscina.isSelected())
			          JOptionPane.showMessageDialog(null,"Please, select Villa type");
			        else {
			          String userEmail = JOptionPane.showInputDialog(null,"Insert your email: ", "Follow villa monitoring", JOptionPane.DEFAULT_OPTION);
			          
			          if(userEmail != null && ("".equals(userEmail)))   
			          {
			            JOptionPane.showMessageDialog(null,"Email can't be empty");
			          }
			          else {
			            if(rdbtnVillaSenzaPiscina.isSelected() && !("".equals(userEmail)) && userEmail != null) {
			            	concretevilla = new ConcreteVilla(2500);
			            	concretevilla.addCustomer(userEmail, concretevilla.getType());
			            }
			            else if(rdbtnVillaConPiscina.isSelected() && !("".equals(userEmail)) && userEmail != null){
			            	concretevilla = new ConcreteVilla(3720);
			            	
			            	concretepiscinadecorator = new ConcretePiscinaDecorator(concretevilla);
			            	concretepiscinadecorator.addCustomer(userEmail, concretevilla.getType());
			            }
			          }
			        }
			}
		});
		btnNewButton_1.setBounds(643, 440, 89, 23);
		chooseVilla.add(btnNewButton_1);
		
		rdbtnVillaSenzaPiscina = new JRadioButton("Villa");
		rdbtnVillaSenzaPiscina.setOpaque(false);
		buttonGroup.add(rdbtnVillaSenzaPiscina);
		rdbtnVillaSenzaPiscina.setForeground(Color.WHITE);
		rdbtnVillaSenzaPiscina.setFont(new Font("SansSerif", Font.ITALIC, 31));
		rdbtnVillaSenzaPiscina.setBounds(145, 285, 232, 32);
		chooseVilla.add(rdbtnVillaSenzaPiscina);
		rdbtnVillaSenzaPiscina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Graphics g = grid.getGraphics();
				if(rdbtnVillaSenzaPiscina.isSelected()) {
					tVilla.setVisible(true);
			    	tVillaP.setVisible(false);
				
					int cont;
					cont = CsvUtilities.checkIfResortIsBusy(CheckInCheckOutPanel.dateChooser.getDate().toString(), CheckInCheckOutPanel.dateChooser_1.getDate().toString(), "Villa");
					if(cont >= 8)
						JOptionPane.showMessageDialog(null, "All standard Villas are occupied");

					int i = 0;
					
					while(i<8 || cont>0) {
						if(cont > 0) {
							Shape shape = ShapeFactory.getShape(Client.shapes[1]);
							Client client = new Client();
							shape.draw(g, client.getX(i), 22, 70, 40);
						}
						else {
							Shape shape = ShapeFactory.getShape(Client.shapes[0]);
							Client client = new Client();
							shape.draw(g, client.getX(i), 22, 70, 40);
						}
						i++;
						cont--;
					}
				}
		    }
		});
		
		rdbtnVillaConPiscina = new JRadioButton("Villa with pool");
		rdbtnVillaConPiscina.setOpaque(false);
		buttonGroup.add(rdbtnVillaConPiscina);
		rdbtnVillaConPiscina.setForeground(Color.WHITE);
		rdbtnVillaConPiscina.setFont(new Font("SansSerif", Font.ITALIC, 31));
		rdbtnVillaConPiscina.setBounds(522, 285, 232, 32);
		chooseVilla.add(rdbtnVillaConPiscina);
		rdbtnVillaConPiscina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				Graphics g = grid.getGraphics();
				if(rdbtnVillaConPiscina.isSelected()) {
					  tVillaP.setVisible(true);
					  tVilla.setVisible(false);
				}
					 
				int cont;
				cont = CsvUtilities.checkIfResortIsBusy(CheckInCheckOutPanel.dateChooser.getDate().toString(), CheckInCheckOutPanel.dateChooser_1.getDate().toString(), "Villa with pool");
				if(cont >= 8)
					JOptionPane.showMessageDialog(null, "All villas with pool are occupied");
				
				int iP = 0;
				
				while(iP<8 || cont>0) {
					if(cont > 0) {
						Shape shape = ShapeFactory.getShape(Client.shapes[3]);
						Client client = new Client();
						shape.draw(g, client.getX(iP), 100, 70, 40);
						Shape shape1 = ShapeFactory.getShape(Client.shapes[4]);
						shape1.draw(g, client.getX(iP), 139, 70, 40);
					}
					else {
						Shape shape = ShapeFactory.getShape(Client.shapes[2]);
						Client client = new Client();
						shape.draw(g, client.getX(iP), 100, 70, 40);
						Shape shape1 = ShapeFactory.getShape(Client.shapes[5]);
						shape1.draw(g, client.getX(iP), 139, 70, 40);
					}
					iP++;
					cont--;
				}
		    }
			
		});
	     
		JButton btnAvanti_1 = new JButton("Next");
		btnAvanti_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 13));
		btnAvanti_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(!rdbtnVillaConPiscina.isSelected() && !rdbtnVillaSenzaPiscina.isSelected())
					JOptionPane.showMessageDialog(null,"Please, select Villa type");
				else {
					if(rdbtnVillaSenzaPiscina.isSelected()){
						concretevilla = new ConcreteVilla(2500);
						
						int cont;
						cont = CsvUtilities.checkIfResortIsBusy(CheckInCheckOutPanel.dateChooser.getDate().toString(), CheckInCheckOutPanel.dateChooser_1.getDate().toString(), "standard");
						if(cont >= 8)
							JOptionPane.showMessageDialog(null, "Select an available Villa type or change the dates");
						else {
							ChooseActivitiesPanel.chckbxAquaTabata.setVisible(false);
							ChooseActivitiesPanel.chckbxHydrobike.setVisible(false);
							ChooseActivitiesPanel.chckbxAcquagym.setVisible(false);
							ChooseActivitiesPanel.chckbxWoga.setVisible(false);
							ChooseActivitiesPanel.chckbxSwimmingPoolGames.setVisible(false);
							
							AppFrame.switchPanels(AppFrame.chooseActivitiesPanel);
							AppFrame.lblChooseActivity.setBackground(Color.decode("#1976D2"));
							AppFrame.lblChooseVilla.setBackground(Color.decode("#03A9F4"));
						}
			        }
					
					if(rdbtnVillaConPiscina.isSelected()){
						concretevilla = new ConcreteVilla(3720);
						piscinadecorator = new ConcretePiscinaDecorator(concretevilla);
						
			            int cont;
						cont = CsvUtilities.checkIfResortIsBusy(CheckInCheckOutPanel.dateChooser.getDate().toString(), CheckInCheckOutPanel.dateChooser_1.getDate().toString(), "pool");
						if(cont >= 8)
							JOptionPane.showMessageDialog(null, "Select an available Villa type or change the dates");
						else {
							ChooseActivitiesPanel.chckbxAquaTabata.setVisible(true);
							ChooseActivitiesPanel.chckbxHydrobike.setVisible(true);
							ChooseActivitiesPanel.chckbxAcquagym.setVisible(true);
							ChooseActivitiesPanel.chckbxWoga.setVisible(true);
							ChooseActivitiesPanel.chckbxSwimmingPoolGames.setVisible(true);
							
							AppFrame.switchPanels(AppFrame.chooseActivitiesPanel);
							AppFrame.lblChooseActivity.setBackground(Color.decode("#1976D2"));
							AppFrame.lblChooseVilla.setBackground(Color.decode("#03A9F4"));					        
						}
							
			        }
					
				}
		      }
		});
		btnAvanti_1.setBounds(772, 439, 90, 24);
		chooseVilla.add(btnAvanti_1);
		
		JLabel lblScegliLaTipologia = new JLabel("Choose villa's type");
		lblScegliLaTipologia.setForeground(Color.WHITE);
		lblScegliLaTipologia.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 43));
		lblScegliLaTipologia.setBounds(248, 11, 403, 48);
		chooseVilla.add(lblScegliLaTipologia);
		
		JButton btnBack_1 = new JButton("Back");
		btnBack_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 13));
		btnBack_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				buttonGroup.clearSelection();
				
				tVilla.setVisible(false);
		    	tVillaP.setVisible(false);
				
				AppFrame.switchPanels(AppFrame.checkInCheckOutPanel);
				AppFrame.lblCheckinCheckout.setBackground(Color.decode("#1976D2"));
				AppFrame.lblChooseVilla.setBackground(Color.decode("#03A9F4"));
		        
		      }
		});
		btnBack_1.setBounds(12, 439, 98, 24);
		chooseVilla.add(btnBack_1);
		
		JLabel lblBackgroundimage_1 = new JLabel();
		lblBackgroundimage_1.setBounds(0, 0, 900, 600);
		chooseVilla.add(lblBackgroundimage_1);
		lblBackgroundimage_1.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/30.jpg")).getImage().getScaledInstance(lblBackgroundimage_1.getWidth(), lblBackgroundimage_1.getHeight(), Image.SCALE_SMOOTH)));
		
		chooseVilla.setVisible(true);
		add(chooseVilla);
	}
	
}
