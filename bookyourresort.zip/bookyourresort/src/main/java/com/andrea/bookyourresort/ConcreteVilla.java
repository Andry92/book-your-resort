package com.andrea.bookyourresort;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.JOptionPane;

/**
 * This class realize an instance of Villa
 */
public class ConcreteVilla implements Villa {

	/**
	 * Constructor of the ConcreteVilla class.
	 * 
	 * @param price price of the Villa
	 */
	public ConcreteVilla(double price) {
		this.price = price;
	}

    /**
     * Declared the double variable price.
     */
    static double price;
    
    /**
     * This method get the type of villa.
     * 
     * @return type of Villa
     */
    public String getType() {
        return "Villa";
    }

    /**
     * This method get the villa's price.
     * @return double the villa's price 
     */
    public double getPrice() {
        return price;
    }

    /**
     * This method add a customer as a follower.
     * 
     * @param userEmail customer's email.
     * @param VillaType villa's type chosen by the customer.
     */
	public void addCustomer(String userEmail, String VillaType) {
    	List<String> rows = Arrays.asList(userEmail, VillaType);
    	
    	boolean emailExists = CsvUtilities.checkIfEmailExists(userEmail);
        if(!emailExists) {
          boolean addLines = CsvUtilities.addLinesToCSVFollowers(rows);
          if(addLines)
            JOptionPane.showMessageDialog(null,"Email registered.\nWe'll send you an email to inform you about this Villa's state\n\n");
          	JOptionPane.showMessageDialog(null, "If you want to proceed with your booking, click on next button or close the window\n");
        }
        else
          JOptionPane.showMessageDialog(null,"Email already exists.\nInsert another email");
    }

	/**
     * This method sends email to all followers of the villa type.
     */
    public void sendMessage() {
    	 
		try {
			String subject;
	    	String body;
	    	SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy", Locale.ENGLISH);
	    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
	    	
			String emails = CsvUtilities.getEmailsVillaType(Customer.villaType);
			
			if(!emails.equals("")) {
				int cont = CsvUtilities.checkIfResortIsBusy(Customer.checkIn.toString(), Customer.checkOut.toString(), Customer.villaType);
				Date parsedCheckInDate = sdf.parse(Customer.checkIn.toString());
		    	String checkIn = format.format(parsedCheckInDate);
		    	
		    	Date parsedCheckOutDate = sdf.parse(Customer.checkOut.toString());
		    	String checkOut = format.format(parsedCheckOutDate);
				
				if(cont >= 8) {
					subject = "Booking of Villa";
					body = "Dear user,"
							+ "\n\nwe wanted to inform you that a user has just booked last Villa available from "+checkIn+" to "+checkOut+"."
							+ "\n\nBest regards,\nBook Your Resort Staff";
				}
				else {
					cont = 8-cont;
					subject = "Booking of Villa";
					body = "Dear user,"
							+ "\n\nwe wanted to inform you that a user has just booked a Villa from "+checkIn+" to "+checkOut+"."
							+ "\nNumber of Villas available for that date's range: "+cont+""
							+ "\n\nMake your reservation as long as the Villas are available!!"
							+ "\n\n Best regards,\nBook Your Resort Staff";
				}
				
				SendEmail.SendEmailToFollowers(emails, subject, body);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
    }
    
    /**
     * This method delete the customer.
     * @param userEmail string that represents the customer's email
     */
    public void deleteCustomer(String userEmail) {
    	CsvUtilities.deleteEmailToCSVFollowers(userEmail);
    }

    

}