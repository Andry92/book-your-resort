package com.andrea.bookyourresort;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.toedter.calendar.JYearChooser;

/**
 * CustomerForm class.
 *
 */
public class CustomerForm  extends JPanel implements ActionListener { 
	  
// Components of the Form 
private JPanel c; 
private JLabel title; 
private JLabel name; 
private JTextField tname; 
private JLabel mno; 
private JTextField tmno; 
private JLabel gender; 
private JRadioButton male; 
private JRadioButton female; 
private ButtonGroup gengp; 
private JLabel dob; 
private JComboBox date; 
private JComboBox month; 
private JLabel add; 
private JTextArea tadd; 
private JCheckBox term; 
private JButton sub; 
private JButton reset; 
static JTextArea tout;
private JLabel res; 
private JTextArea resadd; 
private JLabel lblEmailId;
private JTextField temail;


private JYearChooser year;

private String dates[] 
    = { "1", "2", "3", "4", "5", 
        "6", "7", "8", "9", "10", 
        "11", "12", "13", "14", "15", 
        "16", "17", "18", "19", "20", 
        "21", "22", "23", "24", "25", 
        "26", "27", "28", "29", "30", 
        "31" }; 
private String months[] 
        = { "Jan", "Feb", "Mar", "Apr", 
            "May", "Jun", "July", "Aug", 
            "Sep", "Oct", "Nov", "Dec" }; 
static Customer utente;
   
    /**
     * Constructor of CustomerForm class that create a new JPanel.
     */
    public CustomerForm() 
    {
    	
    	c=new JPanel();
    	setBounds(0, 83, 900, 600);
    	c.setPreferredSize(new Dimension(900, 600));
    	c.setLayout(null); 
        
        JLabel lblReview = new JLabel("Summary");
        lblReview.setForeground(Color.WHITE);
        lblReview.setFont(new Font("SansSerif", Font.BOLD, 25));
        lblReview.setBounds(602, 81, 128, 33);
        c.add(lblReview);
        
        JLabel lblVerify = new JLabel("(Please verify your information)");
        lblVerify.setForeground(Color.WHITE);
        lblVerify.setFont(new Font("SansSerif", Font.BOLD, 19));
        lblVerify.setBounds(518, 108, 296, 33);
        c.add(lblVerify);
        
        year = new JYearChooser();
        year.setBounds(323, 263, 48, 20);
        c.add(year);
        
        
          
        JButton button_2 = new JButton("Back");
        button_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		AppFrame.switchPanels(AppFrame.chooseActivitiesPanel);
                AppFrame.lblCustomerForm.setBackground(Color.decode("#03A9F4"));
                AppFrame.lblChooseActivity.setBackground(Color.decode("#1976D2"));
                
                tout.setText("");
              }
        });
        button_2.setFont(new Font("SansSerif", Font.BOLD, 14));
        button_2.setBounds(12, 439, 98, 24);
        c.add(button_2);
        
        JButton book = new JButton("Book");
        book.setFont(new Font("SansSerif", Font.BOLD, 14));
        book.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	if(tout.getText().equals(""))
                JOptionPane.showMessageDialog(null,"Please, submit your information first");
              else {
                AppFrame.switchPanels(AppFrame.paymentPanel);
                AppFrame.lblCustomerForm.setBackground(Color.decode("#03A9F4"));
                AppFrame.lblPaymentForm.setBackground(Color.decode("#1976D2"));
              }
        	}
		});
        book.setBounds(772, 439, 90, 24);
        c.add(book);
  
        title = new JLabel("Customer Form"); 
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 43)); 
        title.setSize(330, 46);
        title.setLocation(285, 11);
        c.add(title);
  
        name = new JLabel("Name"); 
        name.setForeground(Color.WHITE);
        name.setFont(new Font("SansSerif", Font.BOLD, 25)); 
        name.setSize(93, 33); 
        name.setLocation(71, 79); 
        c.add(name); 
  
        tname = new JTextField(); 
        tname.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tname.setSize(223, 20); 
        tname.setLocation(175, 90); 
        c.add(tname); 
  
        mno = new JLabel("Mobile"); 
        mno.setForeground(Color.WHITE);
        mno.setFont(new Font("SansSerif", Font.BOLD, 25)); 
        mno.setSize(95, 27); 
        mno.setLocation(71, 169); 
        c.add(mno); 
        
        tmno = new JTextField(); 
        tmno.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tmno.setSize(150, 20); 
        tmno.setLocation(176, 177); 
        c.add(tmno); 
  
        gender = new JLabel("Gender"); 
        gender.setForeground(Color.WHITE);
        gender.setFont(new Font("SansSerif", Font.BOLD, 25)); 
        gender.setSize(109, 34); 
        gender.setLocation(71, 204); 
        c.add(gender); 
  
        male = new JRadioButton("Male");
        male.setFont(new Font("SansSerif", Font.PLAIN, 15)); 
        male.setSelected(true); 
        male.setSize(75, 20); 
        male.setLocation(214, 215); 
        c.add(male); 
  
        female = new JRadioButton("Female"); 
        female.setFont(new Font("SansSerif", Font.PLAIN, 15)); 
        female.setSelected(false); 
        female.setSize(80, 20); 
        female.setLocation(291, 215); 
        c.add(female); 
        
        gengp = new ButtonGroup(); 
        gengp.add(male); 
        gengp.add(female); 
  
        dob = new JLabel("DOB"); 
        dob.setForeground(Color.WHITE);
        dob.setFont(new Font("SansSerif", Font.BOLD, 25)); 
        dob.setSize(58, 24); 
        dob.setLocation(71, 259); 
        c.add(dob); 
        
        date = new JComboBox(dates); 
        date.setFont(new Font("Arial", Font.PLAIN, 15)); 
        date.setSize(50, 20); 
        date.setLocation(214, 263); 
        c.add(date); 
  
        month = new JComboBox(months); 
        month.setFont(new Font("Arial", Font.PLAIN, 15)); 
        month.setSize(60, 20); 
        month.setLocation(261, 263); 
        c.add(month);
  
        add = new JLabel("Address"); 
        add.setForeground(Color.WHITE);
        add.setFont(new Font("SansSerif", Font.BOLD, 25)); 
        add.setSize(118, 24); 
        add.setLocation(71, 294); 
        c.add(add); 
  
        tadd = new JTextArea(); 
        tadd.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tadd.setSize(210, 33); 
        tadd.setLocation(188, 300); 
        tadd.setLineWrap(true); 
        c.add(tadd); 
  
        term = new JCheckBox("Accept Terms And Conditions."); 
        term.setFont(new Font("SansSerif", Font.PLAIN, 15)); 
        term.setSize(237, 20); 
        term.setLocation(176, 350); 
        c.add(term); 
        
        sub = new JButton("Submit"); 
        sub.setFont(new Font("SansSerif", Font.BOLD, 14)); 
        sub.setSize(100, 20); 
        sub.setLocation(166, 410); 
        sub.addActionListener(this);
        c.add(sub); 
  
        reset = new JButton("Reset"); 
        reset.setFont(new Font("SansSerif", Font.BOLD, 14)); 
        reset.setSize(100, 20); 
        reset.setLocation(335, 410); 
        reset.addActionListener(this); 
        c.add(reset); 
  
        tout = new JTextArea(); 
        tout.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tout.setSize(327, 249); 
        tout.setLocation(503, 152); 
        tout.setLineWrap(true); 
        tout.setEditable(false); 
        c.add(tout); 
  
        res = new JLabel(""); 
        res.setForeground(new Color(255, 255, 255));
        res.setFont(new Font("SansSerif", Font.PLAIN, 20)); 
        res.setSize(367, 25); 
        res.setLocation(97, 376); 
        c.add(res); 
        
        lblEmailId = new JLabel("Email");
        lblEmailId.setFont(new Font("SansSerif", Font.BOLD, 25));
        lblEmailId.setForeground(Color.WHITE);
        lblEmailId.setBounds(71, 123, 77, 24);
        c.add(lblEmailId);
        
        temail = new JTextField(); 
        temail.setFont(new Font("Arial", Font.PLAIN, 15)); 
        temail.setSize(223, 20); 
        temail.setLocation(175, 130); 
        c.add(temail); 
        
        JLabel lblBackgroundimage_3 = new JLabel("");
        lblBackgroundimage_3.setBounds(0, 0, 900, 543);
        c.add(lblBackgroundimage_3);
        lblBackgroundimage_3.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("/30.jpg")).getImage().getScaledInstance(lblBackgroundimage_3.getWidth(), lblBackgroundimage_3.getHeight(), Image.SCALE_SMOOTH)));
  
        resadd = new JTextArea(); 
        resadd.setFont(new Font("Arial", Font.PLAIN, 15)); 
        resadd.setSize(200, 75); 
        resadd.setLocation(580, 175); 
        resadd.setLineWrap(true); 
        c.add(resadd);
        c.setVisible(true);
        
        
        add(c);
    }
    
    
    /**
     * Method actionPerformed() to get the action performed by the user and act accordingly.
     */
    public void actionPerformed(ActionEvent e) 
    { 
        if (e.getSource() == sub) { 
            if (term.isSelected()) { 
                String data1;
                String data 
                    = "\n  Name : "
                      + tname.getText()+"\n\n"
                      + "  Email : "
                      + temail.getText() + "\n\n"
                      + "  Mobile : "
                      + tmno.getText() + "\n\n"; 
                if (male.isSelected()) 
                    data1 = "  Gender : Male"
                            + "\n\n"; 
                else
                    data1 = "  Gender : Female"
                            + "\n\n"; 
                String data2 
                    = "  DOB : "
                      + (String)date.getSelectedItem() 
                      + "/" + (String)month.getSelectedItem() 
                      + "/" + year.getYear()
                      + "\n\n"; 
  
                String data3 = "  Address : " + tadd.getText(); 
                tout.setText(data + data1 + data2 + data3); 
                tout.setEditable(false); 
                res.setText("  Registration Successfully..");
                
                String villaType;
                
                if(ChooseVillaPanel.rdbtnVillaSenzaPiscina.isSelected())
                	villaType = "Villa";
                else
                	villaType = "Villa with pool";
                
                utente = new Customer(tname.getText(), tmno.getText(), temail.getText(), tadd.getText(), Customer.getActivities(), CheckInCheckOutPanel.dateChooser.getDate(), CheckInCheckOutPanel.dateChooser_1.getDate(), villaType);
                
            } else { 
                tout.setText("");
                resadd.setText("");
                res.setText("Please accept the"
                            + " terms & conditions..");
            } 
        } 
  
        else if (e.getSource() == reset) { 
            String def = ""; 
            tname.setText(def); 
            tadd.setText(def); 
            tmno.setText(def); 
            res.setText(def); 
            tout.setText(def); 
            term.setSelected(false); 
            date.setSelectedIndex(0); 
            month.setSelectedIndex(0); 
            year.getYear();
            resadd.setText(def); 
            temail.setText(def);
        } 

    }	
 }
    

