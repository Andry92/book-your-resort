package com.andrea.bookyourresort;

import java.awt.*;
import javax.swing.*;

/**
 * Class that represents the start point of the program
 */
public class AppFrame extends JFrame{

	private JFrame frame;
	
	private static JLayeredPane layeredPane;
	
	private JPanel topPanel;
	static CheckInCheckOutPanel checkInCheckOutPanel;
	static ChooseVillaPanel chooseVillaPanel;
	static ChooseActivitiesPanel chooseActivitiesPanel;
	static CustomerForm customerFormPanel;
	static Payment paymentPanel;
	
	/* topPanel labels */
	static JLabel lblCheckinCheckout;
	static JLabel lblChooseVilla;
	static JLabel lblChooseActivity;
	static JLabel lblCustomerForm;
	static JLabel lblPaymentForm;
	
	public AppFrame() {
		gui();
		frame.setVisible(true);
	}
	
	public void gui() {
		frame = new JFrame("Book Your Resort");
		frame.setBackground(new Color(224, 255, 255));
		frame.setBounds(300, 90, 900, 600);
		frame.getContentPane().setLayout(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		
		/**
		 * Creation of a new JPanel set to top of the frame.
		 */
		topPanel = new JPanel();
	    topPanel.setBounds(0, 0, 900, 78);
	    frame.getContentPane().add(topPanel);
	    topPanel.setLayout(new GridLayout(0, 5, 0, 0));
	    
	    lblCheckinCheckout = new JLabel("Check-in \\ Check-out");
	    lblCheckinCheckout.setForeground(Color.WHITE);
	    lblCheckinCheckout.setFont(new Font("SansSerif", Font.BOLD, 13));
	    topPanel.add(lblCheckinCheckout);
	    lblCheckinCheckout.setHorizontalAlignment(SwingConstants.CENTER);
	    lblCheckinCheckout.setBackground(Color.decode("#1976D2"));
	    lblCheckinCheckout.setOpaque(true);
	    
	    lblChooseVilla = new JLabel("Choose Villa");
	    lblChooseVilla.setForeground(Color.WHITE);
	    lblChooseVilla.setFont(new Font("SansSerif", Font.BOLD, 13));
	    topPanel.add(lblChooseVilla);
	    lblChooseVilla.setHorizontalAlignment(SwingConstants.CENTER);
	    lblChooseVilla.setBackground(Color.decode("#03A9F4"));
	    lblChooseVilla.setOpaque(true);
	    
	    lblChooseActivity = new JLabel("Choose Activity");
	    lblChooseActivity.setFont(new Font("SansSerif", Font.BOLD, 13));
	    lblChooseActivity.setForeground(Color.WHITE);
	    topPanel.add(lblChooseActivity);
	    lblChooseActivity.setHorizontalAlignment(SwingConstants.CENTER);
	    lblChooseActivity.setBackground(Color.decode("#03A9F4"));
	    lblChooseActivity.setOpaque(true);
	    
	    lblCustomerForm = new JLabel("Customer Form");
	    lblCustomerForm.setForeground(Color.WHITE);
	    lblCustomerForm.setFont(new Font("SansSerif", Font.BOLD, 13));
	    topPanel.add(lblCustomerForm);
	    lblCustomerForm.setHorizontalAlignment(SwingConstants.CENTER);
	    lblCustomerForm.setBackground(Color.decode("#03A9F4"));
	    lblCustomerForm.setOpaque(true);
	    
	    lblPaymentForm = new JLabel("Payment");
	    lblPaymentForm.setForeground(Color.WHITE);
	    lblPaymentForm.setFont(new Font("SansSerif", Font.BOLD, 13));
		topPanel.add(lblPaymentForm);
		lblPaymentForm.setHorizontalAlignment(SwingConstants.CENTER);
		lblPaymentForm.setBackground(Color.decode("#03A9F4"));
		lblPaymentForm.setOpaque(true);
	    
	    
		layeredPane = new JLayeredPane();
		layeredPane.setBounds(0, 83, 900, 600);
		frame.getContentPane().add(layeredPane);
		layeredPane.setLayout(new CardLayout(0, 0));
		
		
		/* CHECK-IN CHECK-OUT PANEL */
		checkInCheckOutPanel = new CheckInCheckOutPanel();
		FlowLayout fl_checkInCheckOutPanel = (FlowLayout) checkInCheckOutPanel.getLayout();
		fl_checkInCheckOutPanel.setVgap(0);
		fl_checkInCheckOutPanel.setHgap(0);
		layeredPane.add(checkInCheckOutPanel, "name_1983615843456");
		
		/* CHOOSE VILLA PANEL */
		chooseVillaPanel = new ChooseVillaPanel();
		FlowLayout fl_chooseVillaPanel = (FlowLayout) checkInCheckOutPanel.getLayout();
		fl_chooseVillaPanel.setVgap(0);
		fl_chooseVillaPanel.setHgap(0);
		layeredPane.add(chooseVillaPanel, "name_1983615843456");
		
		/* CHOOSE ATTIVITA PANEL */
		chooseActivitiesPanel = new ChooseActivitiesPanel();
		FlowLayout fl_chooseActivitiesPanel = (FlowLayout) chooseActivitiesPanel.getLayout();
		fl_chooseActivitiesPanel.setVgap(0);
		fl_chooseActivitiesPanel.setHgap(0);
		layeredPane.add(chooseActivitiesPanel, "name_1983615843456");
		
		/* CUSTOMER FORM PANEL */
	    customerFormPanel = new CustomerForm();
	    FlowLayout fl_customerFormPanel = (FlowLayout) customerFormPanel.getLayout();
	    fl_customerFormPanel.setVgap(0);
	    fl_customerFormPanel.setHgap(0);
	    layeredPane.add(customerFormPanel, "name_1983615843456");
	    
	    /* PAYMENT PANEL */
		paymentPanel = new Payment();
		FlowLayout fl_paymentPanel = (FlowLayout) customerFormPanel.getLayout();
		fl_paymentPanel.setVgap(0);
		fl_paymentPanel.setHgap(0);
		layeredPane.add(paymentPanel, "name_1983615843456");
	}
	
	/**
	 * This method is used to switch from panel to another
	 * @param panel panel where you need to switch
	 */
	public static void switchPanels(JPanel panel) {
		layeredPane.removeAll();
		layeredPane.add(panel);
		layeredPane.repaint();
		layeredPane.revalidate();
	}
	
}
