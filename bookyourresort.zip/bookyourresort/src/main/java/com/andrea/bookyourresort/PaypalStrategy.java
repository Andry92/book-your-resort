package com.andrea.bookyourresort;
import java.util.*;

import javax.swing.JOptionPane;

/**
 * Class used for the payment of a customer with a Paypal account.
 */
public class PaypalStrategy implements PaymentStrategy {

    /**
     * Constructor of the PaypalStrategy class.
     * 
     * @param emailId the user's Paypal email entered during the payment phase.
     * @param password the user's Paypal password entered during the payment phase.
     */
    public PaypalStrategy(String emailId, String password) {
    	this.emailId=emailId;
    	this.password=password;
    }

    /**
     * Declared the string variable emailId.
     */
    private String emailId;

    /**
     * Declared the string variable password.
     */
    private String password;

    /**
     * This method print the successful message if the payment is successful
     */
    public void pay() {
    	JOptionPane.showMessageDialog(null, "Payment with PayPal Successfull!");
    }

}