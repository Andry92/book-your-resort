package com.andrea.bookyourresort;

/**
 * PaymentContext class in which we handle the payment.
 * 
 */
public class PaymentContext {
	
    /**
     * Declared variable paymentStrategy.
     */
	 private PaymentStrategy paymentStrategy;

	 /**
	  * Customer will set what PaymentStrategy to use by calling this method.
	  * @param strategy strategy chosen by a customer.
	  */
	 public void setPaymentStrategy(PaymentStrategy strategy)
	 {
	  this.paymentStrategy = strategy;
	 }

	 /**
	  * This method get the payment strategy.
	  * @return paymentStrategy the instance PaymentStrategy interface. 
	  */
	 public PaymentStrategy getPaymentStrategy()
	 {
	  return paymentStrategy;
	 }
	 
	
	 /**
	  * Customer will pay the amount of payment by calling this method.
	  * 
	  */
	 public void pay()
	 {
	  paymentStrategy.pay();
	 }
}
