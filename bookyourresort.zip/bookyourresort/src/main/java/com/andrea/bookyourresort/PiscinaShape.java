package com.andrea.bookyourresort;

import java.awt.Color;
import java.awt.Graphics;

/**
 * PishinaShape class. In this class we draw the pool shape.
 *
 */
public class PiscinaShape implements Shape {
	
	private boolean busy;
	
	/**
	 * Constructor of the PiscinaShape class.
	 * 
	 * @param b boolean value to check if the villa is busy.
	 */
	public PiscinaShape(boolean b){
		this.busy=b;
	}
	
	
	/**
	 * This method draw the pool shape using x,y coordinates.
	 * 
	 * @param circle a Graphics object of the Graphics class.
	 * @param x x coordinate of pool shape.
	 * @param y y coordinate of pool shape.
	 * @param width width of pool shape.
	 * @param height height of pool shape.
	 */
	@Override
	public void draw(Graphics circle, int x, int y, int width, int height) {
		if(busy){			
			circle.setColor(Color.RED);
			circle.fillOval(x, y, width, height);
	    }
	    else {
	    	circle.setColor(Color.BLUE);
	    	circle.fillOval(x, y, width, height);
	    }
	}

}
